///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <iostream>

// OpenGL / windowing (GLEW + GLFW)
#include <GL/glew.h>
#include <GLFW/glfw3.h>

// Project headers
#include "ShaderManager.h"
// Your project shows camera header as "camera.h". If it is "Camera.h" in your tree,
// change this include accordingly.
#include "camera.h"

class ViewManager
{
public:
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    // create the initial OpenGL display window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // process keyboard events for interaction with the 3D scene
    void ProcessKeyboardEvents();

    // prepare view/projection matrices and push them to the shader each frame
    void PrepareSceneView();

    // --- GLFW C-style callbacks (must be static) ---
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset);

private:
    ShaderManager* m_pShaderManager; // pointer to shader manager object
    GLFWwindow* m_pWindow; // active OpenGL display window
};
