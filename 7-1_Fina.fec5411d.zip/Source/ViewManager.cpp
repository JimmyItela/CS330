///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

namespace
{
    // window & shader uniform names
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    // camera used to view and interact with the 3D scene
    Camera* g_pCamera = nullptr;

    // mouse state
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // projection mode: false = perspective, true = orthographic
    bool bOrthographicProjection = false;

    // simple debounce for P/O keys
    bool gPPressed = false;
    bool gOPressed = false;
}

/***********************************************************
 * ViewManager()
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = NULL;

    g_pCamera = new Camera();

    // default camera parameters
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80.0f; // FOV degrees for perspective
}

/***********************************************************
 * ~ViewManager()
 ***********************************************************/
ViewManager::~ViewManager()
{
    m_pShaderManager = NULL;
    m_pWindow = NULL;

    if (NULL != g_pCamera)
    {
        delete g_pCamera;
        g_pCamera = NULL;
    }
}

/***********************************************************
 * CreateDisplayWindow()
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }
    glfwMakeContextCurrent(window);

    // --------- GLEW initialization (required before any modern GL calls) ---------
    glewExperimental = GL_TRUE; // ensure core profile funcs are exposed
    GLenum glewErr = glewInit();
    if (glewErr != GLEW_OK)
    {
        std::cout << "Failed to initialize GLEW: "
            << reinterpret_cast<const char*>(glewGetErrorString(glewErr)) << std::endl;
        return NULL;
    }
    // -----------------------------------------------------------------------------

    // If you want FPS-style mouse capture, uncomment:
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // register callbacks
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

    // blending for transparency support
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return(window);
}

/***********************************************************
 * Mouse_Position_Callback()
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* /*window*/, double xMousePos, double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xoffset = static_cast<float>(xMousePos) - gLastX;
    float yoffset = gLastY - static_cast<float>(yMousePos); // flip for screen coords

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    if (g_pCamera)
        g_pCamera->ProcessMouseMovement(xoffset, yoffset);
}

/***********************************************************
 * Mouse_Scroll_Callback()
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* /*window*/, double /*xoffset*/, double yoffset)
{
    if (g_pCamera)
        g_pCamera->ProcessMouseScroll(static_cast<float>(yoffset));
}

/***********************************************************
 * ProcessKeyboardEvents()
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    // close window
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    // movement: WASD + Q/E (vertical)
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

    // projection toggle (debounced): P = perspective, O = orthographic
    int pState = glfwGetKey(m_pWindow, GLFW_KEY_P);
    if (pState == GLFW_PRESS && !gPPressed)
    {
        bOrthographicProjection = false;
        gPPressed = true;
    }
    if (pState == GLFW_RELEASE) gPPressed = false;

    int oState = glfwGetKey(m_pWindow, GLFW_KEY_O);
    if (oState == GLFW_PRESS && !gOPressed)
    {
        bOrthographicProjection = true;
        gOPressed = true;
    }
    if (oState == GLFW_RELEASE) gOPressed = false;
}

/***********************************************************
 * PrepareSceneView()
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    // timing
    float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // input
    ProcessKeyboardEvents();

    // view matrix from camera
    view = g_pCamera->GetViewMatrix();

    // projection matrix (toggle with P/O)
    if (!bOrthographicProjection)
    {
        // Perspective
        projection = glm::perspective(
            glm::radians(g_pCamera->Zoom),
            (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
            0.1f, 100.0f);
    }
    else
    {
        // Orthographic � size tuned for default scene
        const float orthoSize = 10.0f;
        float aspect = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

        projection = glm::ortho(
            -orthoSize * aspect, // left
            orthoSize * aspect, // right
            -orthoSize, // bottom
            orthoSize, // top
            0.1f, 100.0f); // near/far
    }

    // push to shader
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}